#! /usr/bin/env python
import sys

def process_key(last_key, values):
    if not values: 
        return

    min_delay = float(min(values))
    max_delay = float(max(values))
    avg_delay = float(sum(values)) / len(values)  

    result = [last_key, min_delay, max_delay, avg_delay]
    print("\t".join(str(v) for v in result)) 

last_key = None
values = []

for line in sys.stdin:
    line = line.strip()
    parts = line.split("\t")

    
    if len(parts) != 3:
        continue

    key, taxi_in, arr_delay = parts

    try:
        combined_delay = int(taxi_in) + int(arr_delay)
    except ValueError:
        continue  

    if last_key is not None and key != last_key:
        process_key(last_key, values)
        values = [combined_delay]
    else:
        values.append(combined_delay)

    last_key = key

process_key(last_key, values)
