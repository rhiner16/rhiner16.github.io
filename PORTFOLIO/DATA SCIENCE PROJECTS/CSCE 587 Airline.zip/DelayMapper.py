#! /usr/bin/env python
import sys

for line in sys.stdin:
    line = line.strip()
    unpacked = line.split(",")
    UniqueCarrier, ArrDelay, Origin, Dest, TaxiIn = [unpacked[i] for i in [8, 14, 16, 17, 19]]

    
    if "NA" in (TaxiIn, ArrDelay):
        continue

    key = "-".join([UniqueCarrier, Dest])
    value = "\t".join([TaxiIn, ArrDelay])
    print("\t".join([key, value]))
